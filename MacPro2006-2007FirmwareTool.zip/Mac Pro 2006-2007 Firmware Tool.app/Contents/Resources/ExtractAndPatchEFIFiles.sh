cd /Volumes/RamDisk

hdiutil attach -nobrowse MacProEFI2006and2007.dmg

cp '/Volumes/Mac Pro EFI Updater/MacProFirmwareUpdate.pkg/Contents/Archive.pax.gz' .
gunzip Archive.pax.gz
pax -r -f Archive.pax

mkdir MacProEFI2007-2006
mkdir MacProEFI2006-2007

cp 'Applications/Utilities/Mac Pro EFI Firmware Update.app/Contents/Resources/EFIUpdaterApp2.efi' MacProEFI2007-2006
cp 'Applications/Utilities/Mac Pro EFI Firmware Update.app/Contents/Resources/LOCKED_MP21_007F_06B.fd' MacProEFI2006-2007/LOCKED_MP11_005C_08B.fd
cp 'Applications/Utilities/Mac Pro EFI Firmware Update.app/Contents/Resources/EfiUpdaterApp2.efi' MacProEFI2006-2007
cp 'Applications/Utilities/Mac Pro EFI Firmware Update.app/Contents/Resources/LOCKED_MP11_005C_08B.fd' MacProEFI2007-2006/LOCKED_MP21_007F_06B.fd

rm -R Applications
rm -R Expanded
rm -R System
rm Payload
hdiutil detach '/Volumes/Mac Pro EFI Update/'

patch MacProEFI2006-2007/EfiUpdaterApp2.efi MacProEFIUpdater2006.patch
patch MacProEFI2007-2006/EfiUpdaterApp2.efi MacProEFIUpdater2007.patch

