#!/bin/bash

updatesdir1="/System/Library/CoreServices/Firmware Updates"
updatesdir2="/System/Library/CoreServices/Firmware Updates/MacProEFIUpdate"
firmwaredir="/Volumes/RamDisk/MacProEFI2007-2006"
firmware="EfiUpdaterApp2.efi"
firmware2="LOCKED_MP21_007F_06B.fd"

rm -r "${updatesdir1}"
mkdir "${updatesdir1}"
mkdir "${updatesdir2}"

cp "${firmwaredir}/${firmware}" "${updatesdir2}"
cp "${firmwaredir}/${firmware2}" "${updatesdir2}"

/usr/sbin/bless -mount / -firmware "${updatesdir2}/${firmware}" -payload "${updatesdir2}/${firmware2}" -options "-x efi-apple-payload0-data" --verbose

exit 0
